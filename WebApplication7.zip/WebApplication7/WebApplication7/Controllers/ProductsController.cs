﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    public class ProductsController : Controller
    {
        static List <Product> AllProducts;
        static ProductsController()
        {
            AllProducts = new List<Product>()
            {
              new Product() { Id = 111, Name = "HP Laptop", category = "Electronics" },
              new Product() { Id = 111, Name = "HP Laptop", category = "Electronics" },
              new Product() { Id = 111, Name = "HP Laptop", category = "Electronics" },
              new Product() { Id = 111, Name = "HP Laptop", category = "Electronics" },
              new Product() { Id = 111, Name = "HP Laptop", category = "Electronics" }
            };
        }

    public IActionResult Index()
        {
            return View();
        }
        public IActionResult Hello()
        {
            return View();
        }
        public IActionResult Test()
        {
            return View();
        }

        public IActionResult DisplayProducts()
        {
            return View(AllProducts);
        }
        // HTTP GET AS WITHOUT ATTRIBUTE
        public IActionResult Create()
        {
            Product p = new Product();
            return View();
        }

        // HTTP POST AS WITH ATTRIBUTE
        public IActionResult Create( Product P)
        {
            if (P != null)
                AllProducts.Add(P);
            return RedirectToAction("DisplayProducts");
        }

        public IActionResult Edit (int ID)
        {
            var product = AllProducts.Find(P => P.Id == ID );
            return View (AllProducts);
        }

        public IActionResult Edit(int ID, Product P)
        {
            var  P1 = AllProducts.Find(P => P.Id == ID);
            AllProducts.Remove(P1);
            AllProducts.Add(P);
            return RedirectToAction("DisplayProducts");
        }






    }
}
